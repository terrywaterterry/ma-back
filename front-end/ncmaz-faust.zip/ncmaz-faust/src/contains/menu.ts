import { MenuLocationEnum } from "@/__generated__/graphql";

export const PRIMARY_LOCATION = MenuLocationEnum.Primary;
export const FOOTER_LOCATION = MenuLocationEnum.Footer;
