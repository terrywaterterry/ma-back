<?php
require plugin_dir_path(__FILE__) . 'ncmazfc-register-blocks.php';
require plugin_dir_path(__FILE__) .  'ncmazfc-blocks-posts-query.php';
require plugin_dir_path(__FILE__) . 'ncmazfc-blocks-terms-query.php';
require plugin_dir_path(__FILE__) . 'ncmazfc-blocks-render-callback.php';
